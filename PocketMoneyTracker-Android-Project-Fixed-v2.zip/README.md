# Pocket Money Tracker — Android source

This is a native Android Java project for Pocket Money Tracker.

## Build with GitHub Actions

1. Upload `PocketMoneyTracker-Android-Project-Final.zip` to the root of your GitHub repository (replace the older ZIP).
2. Configure a workflow to unpack this archive into `project-src` and run `gradle -p project-src :app:assembleDebug`.
3. If the workflow succeeds, download the `PocketMoneyTracker-debug-apk` artifact and extract `app-debug.apk`.

## Included

- Android Gradle project files at the archive root
- Native Java app source
- Emerald wallet launcher icon assets
- Offline local transaction and savings-goal storage
- CSV and JSON export through Android's save-document dialog

The earlier compile issue was caused by passing an integer transaction index into `editTxn`, whose second argument is a String transaction type. The corrected transaction-card click passes the stored kind (`Income` or `Expense`) instead.

The source ZIP has been checked structurally and the specific incompatible argument call is corrected. A successful Android SDK compilation still must be confirmed by GitHub Actions.
